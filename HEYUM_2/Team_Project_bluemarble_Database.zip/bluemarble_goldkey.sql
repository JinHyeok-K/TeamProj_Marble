-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: database-1.cslkca43ufc7.ap-northeast-2.rds.amazonaws.com    Database: bluemarble
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `goldkey`
--

DROP TABLE IF EXISTS `goldkey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `goldkey` (
  `gk_no` int NOT NULL AUTO_INCREMENT,
  `gk_name` varchar(100) DEFAULT NULL,
  `gk_content` varchar(5000) DEFAULT NULL,
  `gk_value` int DEFAULT NULL,
  PRIMARY KEY (`gk_no`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goldkey`
--

LOCK TABLES `goldkey` WRITE;
/*!40000 ALTER TABLE `goldkey` DISABLE KEYS */;
INSERT INTO `goldkey` VALUES (1,'노벨 평화상','30만원 지급',300000),(2,'고속도로','출발지로 바로 가시오.',0),(3,'관광여행','서울로 가시오.',39),(4,'관광여행','부산으로 가시오.',25),(5,'관광여행','제주도로 가시오.',5),(6,'뒤로가시오','2칸 뒤로 가시오.',-2),(7,'뒤로가시오','3칸 뒤로 가시오.',-3),(8,'무인도로 가시오','무인도로 가시오',20),(9,'사회복지기금 배당','사회복지기금 수령처로 가시오.',30),(10,'세계일주','한 바퀴 돌아 제자리로 가시오.',40),(11,'우주여행','우주여행 승강장으로 바로 이동하시오.',10),(12,'우주여행','우주여행 승강장으로 바로 이동하시오.',10),(13,'노벨 평화상','30만원 지급',300000),(14,'노후연금','5만원 지급',50000),(15,'복권당첨','20만원 지급',200000),(16,'생일 축하','10만원 지급',100000),(17,'자동차 경주 우승','10만원 지급',100000),(18,'장학금','10만원 지급',100000),(19,'파티 초대권','15만원 지급',150000),(20,'건물 방범비','호텔 1채당 5만원, 빌딩 1채당 3만원, 별장 1채당 1만원 지출',0),(21,'건물 수리비','호텔 1채당 10만원, 빌딩 1채당 5만원, 별장 1채당 3만원 지출',0),(22,'건물 정기종합소득세','호텔 1채당 15만원, 빌딩 1채당 10만원, 별장 1채당 5만원 지출',0),(23,'과속운전','5만원 지출',50000),(24,'병원비','5만원 지출',50000),(25,'해외유학','10만원 지출',100000),(26,'무인도 탈출용 무전기','무인도에서 바로 탈출한다.',0),(27,'건물 방범비','호텔 1채당 5만원, 빌딩 1채당 3만원, 별장 1채당 1만원 지출',0),(28,'건물 수리비','호텔 1채당 10만원, 빌딩 1채당 5만원, 별장 1채당 3만원 지출',0),(29,'건물 정기종합소득세','호텔 1채당 15만원, 빌딩 1채당 10만원, 별장 1채당 5만원 지출',0),(30,'불법토토','50만원 지급',500000);
/*!40000 ALTER TABLE `goldkey` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-13 20:42:39
