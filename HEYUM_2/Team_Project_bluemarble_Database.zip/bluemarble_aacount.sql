-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: database-1.cslkca43ufc7.ap-northeast-2.rds.amazonaws.com    Database: bluemarble
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `aacount`
--

DROP TABLE IF EXISTS `aacount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aacount` (
  `ac_no` int NOT NULL AUTO_INCREMENT,
  `ac_id` varchar(100) NOT NULL,
  `ac_pw` varchar(1000) NOT NULL,
  `ac_email` varchar(100) NOT NULL,
  `ac_name` varchar(45) NOT NULL,
  `ac_nickname` varchar(100) NOT NULL,
  `ac_profileimg` varchar(1000) NOT NULL,
  `ac_phone` varchar(50) NOT NULL,
  `ac_type` int NOT NULL DEFAULT '1',
  `ac_since` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ac_pw_sec` varchar(100) NOT NULL DEFAULT '0000',
  `win` int NOT NULL DEFAULT '0',
  `lose` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ac_no`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aacount`
--

LOCK TABLES `aacount` WRITE;
/*!40000 ALTER TABLE `aacount` DISABLE KEYS */;
INSERT INTO `aacount` VALUES (1,'1234','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','tgaggr@naver.com','qwer','즐거운마블','KakaoTalk_20220526_095826341.jpg','010-4444-4444',1,'2022-05-27 06:54:55','0000',9,9),(2,'asdf','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','kyu05017@naver.com','test2','test2','default.jpg','010-4444-4444',1,'2022-05-27 06:54:55','0000',7,4),(3,'qwer','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','kyu05017@naver.com','test3','test3','default.jpg','010-4444-4444',1,'2022-05-27 06:54:55','0000',1,1),(4,'aaaa','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','kyu05017@naver.com','test4','test4','카톡프로필2.PNG','010-4444-4444',1,'2022-05-27 06:54:55','0000',2,3),(15,'chae','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','kyu05017@naver.com','테스터1','지원아빠','logo.png','010-8905-8755',1,'2022-05-28 07:28:15','0000',6,5),(16,'jamie','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','kyu05017@naver.com','테스터2','지원엄마','default.jpg','010-4444-4444',1,'2022-05-28 07:29:06','0000',2,4),(17,'cjw','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','kyu05017@naver.com','테스터3','지원이','default.jpg','010-4444-4444',1,'2022-05-28 07:29:06','0000',0,0),(18,'chae4','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','kyu05017@naver.com','테스터4','테스터4','default.jpg','010-4444-4444',1,'2022-05-28 07:29:06','0000',0,0),(19,'kyu0501','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','kyu05017@hanmail.net','김규석','김규석멘2','20200116_14421413.jpg','010-4444-4444',1,'2022-05-31 00:45:23','0000',17,6),(22,'kyu05017@naver.com','wicShCaTFaoJUDJWiXxf5M4i5szo8xhhnJnr1Kg9dqU','kyu05017@naver.com','김규석','kyu05017','11.jpg','010-4339-7275',2,'2022-05-31 03:15:09','0000',0,0),(24,'admin','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','kyu05017@naver.com','qwer','운영자','억울이1.jpg','010-4444-4444',0,'0000-00-00 00:00:00','0000',2,2),(28,'kyu0550178','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','kyu05017@kakao.com','김규석','kyu0550178','default.jpg','010-4444-4444',1,'2022-06-08 06:43:55','0000',0,0),(29,'kimmyungho1003','845595a6a0c7e98dc1e74eaf2785702e0baca66f97ced5519fd722ca2b7d72921329912612a0a481a8d346dc7137fe990c76d83b07c8ac1522e1457bdc8b47b4','kimmyungho1003@naver.com','김명호','김노인','default.jpg','010-4925-9039',1,'2022-06-09 07:44:01','0000',0,1),(30,'asdasd','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','kyu0501@ggg.com','김규석','asdasd','default.jpg','010-4444-4444',1,'2022-06-10 02:07:02','0000',0,0),(31,'Marble','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','1231123231231adsdsad@naver.com','김지웅','마블고수','default.jpg','010-1234-5678',1,'2022-06-10 05:11:35','0000',0,1),(32,'junseok2217','bf400c2a1cbc2c5536aec42018864edb5738ed69bf5488a017a1aead21f888ae05a13c2f30de004a4a6fa4eedeb8c8d62f79712a4f8489e7eca408e57b36c250','junseok2217@naver.com','나야나','한씨','default.jpg','010-4963-2217',1,'2022-06-10 05:32:38','0000',0,1),(33,'abcdefg','263fec58861449aacc1c328a4aff64aff4c62df4a2d50b3f207fa89b6e242c9aa778e7a8baeffef85b6ca6d2e7dc16ff0a760d59c13c238f6bcdc32f8ce9cc62','sbin0114@naver.com','티모','adcd','default.jpg','010-5634-5132',1,'2022-06-10 05:33:48','0000',0,1),(34,'qweqwe','bb77c4439bf7301fb0bd422a47103e7c16a060e64b42124ffb9becaa3852c32f84ec2ed6298a0cbeace79846e342314a00e4212b2d15bafc0893c9333a5a3680','lvbluechair@naver.com','아아아','아호','default.jpg','010-1234-5557',1,'2022-06-10 07:35:38','0000',0,0);
/*!40000 ALTER TABLE `aacount` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-13 20:42:39
